from flask import Flask, render_template, request, redirect, session, send_file

app = Flask(__name__)
app.secret_key = "secret"

ADMIN_PIN = "1234"

# ------------------------
# DATA
# ------------------------
students = {
    "2023-0001": {"name": "Dela Cruz, Juan", "balance": 150.00, "pin": "1111"},
    "2023-0002": {"name": "Santos, Maria", "balance": 200.00, "pin": "2222"}
}

menu = {
    1: {"name": "Burger", "price": 35.00},
    2: {"name": "Fries", "price": 30.00},
    3: {"name": "Hotdog", "price": 25.00},
    4: {"name": "Juice", "price": 20.00}
}

total_sales = {i: 0 for i in menu}
total_revenue = {i: 0.0 for i in menu}
transaction_history = []

# ------------------------
# LOGIN
# ------------------------
@app.route("/", methods=["GET", "POST"])
def login():
    error = None

    if request.method == "POST":
        student_id = request.form.get("student_id", "").strip()

        if not student_id:
            error = "Student ID required"
        elif student_id not in students:
            error = "Student not found"
        else:
            session.clear()
            session["student_id"] = student_id
            session["tray"] = {}
            return redirect("/menu")

    return render_template("login.html", error=error)


# ------------------------
# ADMIN LOGIN
# ------------------------
@app.route("/admin-login", methods=["POST"])
def admin_login():
    pin = request.form.get("pin", "").strip()

    if not pin:
        return "PIN required"

    if pin != ADMIN_PIN:
        return "Invalid PIN"

    session.clear()
    session["admin"] = True
    return redirect("/admin")


# ------------------------
# MENU
# ------------------------
@app.route("/menu", methods=["GET", "POST"])
def menu_page():
    if "student_id" not in session:
        return redirect("/")

    student = students[session["student_id"]]
    error = None

    if request.method == "POST":
        item = request.form.get("item")
        qty = request.form.get("qty")

        try:
            item = int(item)
            qty = int(qty)

            if item not in menu:
                error = "Invalid item"
            elif qty <= 0:
                error = "Quantity must be positive"
            else:
                tray = session.get("tray", {})
                tray[str(item)] = tray.get(str(item), 0) + qty
                session["tray"] = tray

        except:
            error = "Invalid input"

    return render_template("menu.html", menu=menu, student=student, error=error)


# ------------------------
# TRAY
# ------------------------
@app.route("/tray", methods=["GET", "POST"])
def tray():
    if "student_id" not in session:
        return redirect("/")

    student = students[session["student_id"]]
    tray = session.get("tray", {})
    error = None

    if request.method == "POST":
        action = request.form.get("action")
        item_id = request.form.get("item_id")

        if item_id not in tray:
            error = "Item not found in tray"
        else:
            if action == "plus":
                tray[item_id] += 1

            elif action == "minus":
                if tray[item_id] > 1:
                    tray[item_id] -= 1
                else:
                    tray.pop(item_id)

            elif action == "checkout":
                if not tray:
                    error = "Tray is empty"
                else:
                    return redirect("/pay")

        session["tray"] = tray

    total = sum(menu[int(i)]["price"] * q for i, q in tray.items())

    return render_template("tray.html", tray=tray, menu=menu, total=total, error=error)


# ------------------------
# PAY (PIN CHECK)
# ------------------------
@app.route("/pay", methods=["GET", "POST"])
def pay():
    if "student_id" not in session:
        return redirect("/")

    student = students[session["student_id"]]
    tray = session.get("tray", {})
    error = None

    total = sum(menu[int(i)]["price"] * q for i, q in tray.items())

    if request.method == "POST":
        pin = request.form.get("pin", "").strip()

        if not tray:
            error = "Tray is empty"

        elif not pin:
            error = "PIN required"

        elif pin != student["pin"]:
            error = "Incorrect PIN"

        elif student["balance"] < total:
            error = "Insufficient balance"

        else:
            student["balance"] -= total

            items = []
            for i, q in tray.items():
                total_sales[int(i)] += q
                total_revenue[int(i)] += q * menu[int(i)]["price"]
                items.append(f"{menu[int(i)]['name']} x{q}")

            transaction_history.append(
                f"{student['name']} - {', '.join(items)}"
            )

            session["tray"] = {}
            return redirect("/success")

    return render_template("pay.html", total=total, error=error)


# ------------------------
# ADMIN PANEL
# ------------------------
@app.route("/admin", methods=["GET", "POST"])
def admin():
    if "admin" not in session:
        return redirect("/")

    error = None

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        price = request.form.get("price", "").strip()

        if not name:
            error = "Item name required"
        elif not price:
            error = "Price required"
        else:
            try:
                price = float(price)
                if price <= 0:
                    error = "Price must be positive"
                else:
                    new_id = max(menu.keys()) + 1
                    menu[new_id] = {"name": name, "price": price}
                    total_sales[new_id] = 0
                    total_revenue[new_id] = 0.0
            except:
                error = "Invalid price"

    total_earned = sum(total_revenue.values())

    return render_template(
        "admin.html",
        menu=menu,
        sales=total_sales,
        revenue=total_revenue,
        total_earned=total_earned,
        history=transaction_history,
        error=error
    )


# ------------------------
# EXPORT REPORT
# ------------------------
@app.route("/export")
def export():
    filename = "report.txt"

    total_earned = sum(total_revenue.values())

    with open(filename, "w", encoding="utf-8") as f:
        f.write("SESSION REPORT\n\n")
        f.write(f"{'Item':<15}{'Sold':<10}{'Revenue':<10}\n")

        for i in menu:
            f.write(f"{menu[i]['name']:<15}{total_sales[i]:<10}₱{total_revenue[i]:.2f}\n")

        f.write(f"\nTotal: ₱{total_earned:.2f}\n\n")
        f.write("History\n")

        for h in transaction_history:
            f.write(h + "\n")

    return send_file(filename, as_attachment=True)


# ------------------------
# SUCCESS
# ------------------------
@app.route("/success")
def success():
    return render_template("success.html")


# ------------------------
# LOGOUT
# ------------------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)