from flask import Flask, render_template, request, redirect, session, send_file
from datetime import datetime
import time

app = Flask(__name__)
app.secret_key = "secret"

ADMIN_PIN = "1234"

# ---------------- DATA ----------------
students = {
    "2023-0001": {"name": "Dela Cruz, Juan", "balance": 150.00, "pin": "1111"},
    "2023-0002": {"name": "Santos, Maria", "balance": 200.00, "pin": "2222"}
}

menu = {
    1: {"name": "Burger", "price": 35.00},
    2: {"name": "Fries", "price": 30.00},
    3: {"name": "Hotdog", "price": 25.00},
    4: {"name": "Juice", "price": 20.00}
}

total_sales = {i: 0 for i in menu}
total_revenue = {i: 0.0 for i in menu}
transaction_history = []

# TRUE APP START TIME
session_start_time = time.time()


# ---------------- LOGIN ----------------
@app.route("/", methods=["GET", "POST"])
def login():
    error = request.args.get("error")

    if request.method == "POST":
        sid = request.form.get("student_id", "").strip()

        if sid in students:
            session.clear()
            session["student_id"] = sid
            session["tray"] = {}
            session["attempts"] = 0
            return redirect("/menu")
        else:
            error = "Student not found"

    return render_template("login.html", error=error)


# ---------------- ADMIN LOGIN ----------------
@app.route("/admin-login", methods=["POST"])
def admin_login():
    pin = request.form.get("pin", "").strip()

    if pin == ADMIN_PIN:
        session.clear()
        session["admin"] = True
        return redirect("/admin")

    return redirect("/?error=Invalid PIN")


# ---------------- MENU ----------------
@app.route("/menu", methods=["GET", "POST"])
def menu_page():
    if "student_id" not in session:
        return redirect("/")

    student = students[session["student_id"]]
    error = None

    if request.method == "POST":
        try:
            item = int(request.form.get("item"))
            qty = int(request.form.get("qty"))

            if item in menu and qty > 0:
                tray = session.get("tray", {})
                tray[str(item)] = tray.get(str(item), 0) + qty
                session["tray"] = tray
            else:
                error = "Invalid input"
        except:
            error = "Invalid input"

    return render_template("menu.html", menu=menu, student=student, error=error)


# ---------------- TRAY ----------------
@app.route("/tray", methods=["GET", "POST"])
def tray():
    if "student_id" not in session:
        return redirect("/")

    tray = session.get("tray", {})
    error = None

    if request.method == "POST":
        action = request.form.get("action")
        item_id = request.form.get("item_id")

        if action == "checkout":
            if tray:
                return redirect("/pay")
            error = "Tray empty"

        elif item_id in tray:
            if action == "plus":
                tray[item_id] += 1
            elif action == "minus":
                tray[item_id] -= 1
                if tray[item_id] <= 0:
                    tray.pop(item_id)
        else:
            error = "Item not found"

        session["tray"] = tray

    total = sum(menu[int(i)]["price"] * q for i, q in tray.items())

    return render_template("tray.html", tray=tray, menu=menu, total=total, error=error)


# ---------------- PAY ----------------
@app.route("/pay", methods=["GET", "POST"])
def pay():
    if "student_id" not in session:
        return redirect("/")

    student = students[session["student_id"]]
    tray = session.get("tray", {})

    if not tray:
        return redirect("/tray")

    error = None
    total = sum(menu[int(i)]["price"] * q for i, q in tray.items())

    if request.method == "POST":
        pin = request.form.get("pin", "")
        attempts = session.get("attempts", 0)

        if attempts >= 3:
            session.clear()
            return redirect("/?error=Too many failed attempts")

        if pin != student["pin"]:
            session["attempts"] = attempts + 1
            error = "Wrong PIN"

        elif student["balance"] < total:
            error = "Insufficient balance"

        else:
            student["balance"] -= total
            session["attempts"] = 0

            items = []
            for i, q in tray.items():
                i = int(i)
                total_sales[i] += q
                total_revenue[i] += q * menu[i]["price"]
                items.append(f"{menu[i]['name']} x{q}")

            transaction_history.append(
                f"{student['name']} - {', '.join(items)}"
            )

            session["tray"] = {}
            return redirect("/success")

    return render_template("pay.html", total=total, error=error)


# ---------------- ADMIN ----------------
@app.route("/admin", methods=["GET", "POST"])
def admin():
    if "admin" not in session:
        return redirect("/")

    error = None

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        price = request.form.get("price", "").strip()

        try:
            price = float(price)

            if name and price > 0:
                new_id = max(menu.keys()) + 1
                menu[new_id] = {"name": name, "price": price}
                total_sales[new_id] = 0
                total_revenue[new_id] = 0.0
            else:
                error = "Invalid input"
        except:
            error = "Invalid price"

    total_earned = sum(total_revenue.values())

    return render_template(
        "admin.html",
        menu=menu,
        sales=total_sales,
        revenue=total_revenue,
        total_earned=total_earned,
        history=transaction_history,
        error=error
    )


# ---------------- EXPORT (FINAL FIXED TABLE + DYNAMIC WIDTH + RUNTIME) ----------------
@app.route("/export")
def export():
    if "admin" not in session:
        return redirect("/")

    total_earned = sum(total_revenue.values())
    total_items = sum(total_sales.values())

    now = datetime.now()
    date = now.strftime("%m/%d/%y")

    runtime_seconds = int(time.time() - session_start_time)
    h = runtime_seconds // 3600
    m = (runtime_seconds % 3600) // 60
    s = runtime_seconds % 60
    runtime = f"{h:02d}:{m:02d}:{s:02d}"

    file = "report.txt"

    # dynamic width based on longest item name
    longest = max(len(menu[i]["name"]) for i in menu)
    col1 = max(20, longest + 2)
    col2 = 10
    col3 = 15

    with open(file, "w", encoding="utf-8-sig") as f:
        f.write("SESSION REPORT\n\n")

        f.write(f"{'ITEM':<{col1}}{'SOLD':<{col2}}{'REVENUE':<{col3}}\n")
        f.write("-" * (col1 + col2 + col3) + "\n")

        for i in menu:
            name = menu[i]["name"]
            sold = total_sales[i]
            revenue = f"₱{total_revenue[i]:.2f}"

            f.write(f"{name:<{col1}}{sold:<{col2}}{revenue:<{col3}}\n")

        f.write("-" * (col1 + col2 + col3) + "\n\n")

        f.write(f"TOTAL REVENUE: ₱{total_earned:.2f}\n")
        f.write(f"TOTAL ITEMS SOLD: {total_items}\n")
        f.write(f"DATE: {date}\n")
        f.write(f"SESSION RUN TIME: {runtime}\n\n")

        f.write("HISTORY\n")
        f.write("-" * (col1 + col2 + col3) + "\n")
        for h in transaction_history:
            f.write(h + "\n")

    return send_file(file, as_attachment=True)


# ---------------- OTHER ----------------
@app.route("/success")
def success():
    return render_template("success.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


# ---------------- RUN ----------------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)