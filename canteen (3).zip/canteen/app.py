from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = "secret"

#admin pin
ADMIN_PIN = "1234"

#student info
students = {
    "2023-0001": {"name": "Dela Cruz, Juan", "balance": 150.00},
    "2023-0002": {"name": "Santos, Maria", "balance": 200.00}
}

#menu info
menu = {
    1: {"name": "Burger", "price": 35.00},
    2: {"name": "Fries", "price": 30.00},
    3: {"name": "Hotdog", "price": 25.00},
    4: {"name": "Juice", "price": 20.00}
}

#sales tracker
total_sales = {item: 0 for item in menu}
total_revenue = {item: 0.0 for item in menu}


#login 
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        student_id = request.form.get("student_id")

        if student_id in students:
            session.clear()
            session["student_id"] = student_id
            session["tray"] = {}
            return redirect("/menu")

        return "Student not found"

    return render_template("login.html")


#admin login
@app.route("/admin-login", methods=["POST"])
def admin_login():
    pin = request.form.get("pin")

    if pin == ADMIN_PIN:
        session.clear()
        session["admin"] = True
        return redirect("/admin")

    return "Invalid PIN"


#menu
@app.route("/menu", methods=["GET", "POST"])
def menu_page():
    if "student_id" not in session:
        return redirect("/")

    student = students[session["student_id"]]

    if request.method == "POST":
        item = request.form.get("item")
        qty = int(request.form.get("qty", 1))

        tray = session.get("tray", {})
        tray[str(item)] = tray.get(str(item), 0) + qty
        session["tray"] = tray

    return render_template("menu.html", menu=menu, student=student)


#tray
@app.route("/tray", methods=["GET", "POST"])
def tray():
    if "student_id" not in session:
        return redirect("/")

    student = students[session["student_id"]]
    tray = session.get("tray", {})

    if request.method == "POST":
        action = request.form.get("action")
        item_id = request.form.get("item_id")

        if action == "plus":
            tray[item_id] = tray.get(item_id, 0) + 1

        elif action == "minus":
            if tray.get(item_id, 0) > 1:
                tray[item_id] -= 1
            else:
                tray.pop(item_id, None)

        elif action == "finalize":
            if not tray:
                return "Tray is empty"

            total = sum(menu[int(i)]["price"] * q for i, q in tray.items())

            if student["balance"] >= total:
                student["balance"] -= total

                for i, q in tray.items():
                    total_sales[int(i)] += q
                    total_revenue[int(i)] += q * menu[int(i)]["price"]

                session["tray"] = {}
                return redirect("/success")
            else:
                return "Insufficient balance"

        session["tray"] = tray
        return redirect("/tray")

    total = sum(menu[int(i)]["price"] * q for i, q in tray.items())

    return render_template("tray.html", tray=tray, menu=menu, total=total, student=student)


#success
@app.route("/success")
def success():
    return render_template("success.html")


#admin panel
@app.route("/admin")
def admin():
    if "admin" not in session:
        return redirect("/")

    return render_template("admin.html",
                           menu=menu,
                           sales=total_sales,
                           revenue=total_revenue)


#logout
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)